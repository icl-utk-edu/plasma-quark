#ifndef BLAS_H
#define BLAS_H

#include "blas_dense.h"
#include "blas_sparse.h"
#include "blas_extended.h"

#endif
 /* BLAS_H */
