#ifndef BLAS_DENSE_H
#define BLAS_DENSE_H

#include "blas_enum.h"
#include "blas_dense_proto.h"

#endif
  /* BLAS_DENSE_H */
