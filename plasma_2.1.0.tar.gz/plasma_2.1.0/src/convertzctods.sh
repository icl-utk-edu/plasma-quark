../tools/convertzctods.sh zcgesv.c dsgesv.c
../tools/convertzctods.sh pzlag2c.c pdlag2s.c
../tools/convertzctods.sh pclag2z.c pslag2d.c
