/* ///////////////////////////// P /// L /// A /// S /// M /// A /////////////////////////////// */
/* ///                    PLASMA computational routines (version 2.1.0)                      ///
 * ///                    Author: Hatem Ltaief, Jakub Kurzak                                 ///
 * ///                    Release Date: November, 15th 2009                                  ///
 * ///                    PLASMA is a software package provided by Univ. of Tennessee,       ///
 * ///                    Univ. of California Berkeley and Univ. of Colorado Denver          /// */
/* ///////////////////////////////////////////////////////////////////////////////////////////// */
#include "common.h"

/* /////////////////////////// P /// U /// R /// P /// O /// S /// E /////////////////////////// */
// PLASMA_sormqr - overwrites the general M-by-N matrix C with Q*C, where Q is an orthogonal
// matrix (unitary in the complex case) defined as the product of elementary reflectors returned
// by PLASMA_sgeqrf. Q is of order M.

/* ///////////////////// A /// R /// G /// U /// M /// E /// N /// T /// S ///////////////////// */
// side     PLASMA_enum (IN)
//          Intended usage:
//          = PlasmaLeft:  apply Q or Q**T from the left;
//          = PlasmaRight: apply Q or Q**T from the right.
//          Currently only PlasmaLeft is supported.
//
// trans    PLASMA_enum (IN)
//          Intended usage:
//          = PlasmaNoTrans:   no transpose, apply Q;
//          = PlasmaTrans: conjugate transpose, apply Q**T.
//          Currently only PlasmaTrans is supported.
//
// M        int (IN)
//          The number of rows of the matrix C. M >= 0.
//
// N        int (IN)
//          The number of columns of the matrix C. N >= 0.
//
// K        int (IN)
//          The number of columns of elementary tile reflectors whose product defines the matrix Q.
//          M >= K >= 0.
//
// A        float* (IN)
//          Details of the QR factorization of the original matrix A as returned by PLASMA_sgeqrf.
//
// LDA      int (IN)
//          The leading dimension of the array A. LDA >= max(1,M);
//
// T        float* (IN)
//          Auxiliary factorization data, computed by PLASMA_sgeqrf.
//
// B        float* (INOUT)
//          On entry, the M-by-N matrix B.
//          On exit, B is overwritten by Q*B or Q**T*B.
//
// LDB      int (IN)
//          The leading dimension of the array C. LDC >= max(1,M).

/* ///////////// R /// E /// T /// U /// R /// N /////// V /// A /// L /// U /// E ///////////// */
//          = 0: successful exit
//          < 0: if -i, the i-th argument had an illegal value

/* //////////////////////////////////// C /// O /// D /// E //////////////////////////////////// */
int PLASMA_sormqr(PLASMA_enum side, PLASMA_enum trans, int M, int N, int K, float *A,
                  int LDA, float *T, float *B, int LDB)
{
    int NB, MT, NT, KT;
    int status;
    float *Abdl;
    float *Bbdl;
    float *Tbdl;
    plasma_context_t *plasma;

    plasma = plasma_context_self();
    if (plasma == NULL) {
        plasma_fatal_error("PLASMA_sormqr", "PLASMA not initialized");
        return PLASMA_ERR_NOT_INITIALIZED;
    }
    /* Check input arguments */
    if (side != PlasmaLeft) {
        plasma_error("PLASMA_sormqr", "only PlasmaLeft supported");
        return PLASMA_ERR_NOT_SUPPORTED;
    }
    if (trans != PlasmaTrans) {
        plasma_error("PLASMA_sormqr", "only PlasmaTrans supported");
        return PLASMA_ERR_NOT_SUPPORTED;
    }
    if (M < 0) {
        plasma_error("PLASMA_sormqr", "illegal value of M");
        return -3;
    }
    if (N < 0) {
        plasma_error("PLASMA_sormqr", "illegal value of N");
        return -4;
    }
    if (K < 0) {
        plasma_error("PLASMA_sormqr", "illegal value of K");
        return -5;
    }
    if (LDA < max(1, M)) {
        plasma_error("PLASMA_sormqr", "illegal value of LDA");
        return -7;
    }
    if (LDB < max(1, M)) {
        plasma_error("PLASMA_sormqr", "illegal value of LDB");
        return -10;
    }
    /* Quick return - currently NOT equivalent to LAPACK's:
     * CALL DLASET( 'Full', MAX( M, N ), NRHS, ZERO, ZERO, B, LDB ) */
    if (min(M, min(N, K)) == 0)
        return PLASMA_SUCCESS;

    /* Tune NB & IB depending on M, K & N; Set NBNBSIZE */
    status = plasma_tune(PLASMA_FUNC_SGELS, M, K, N);
    if (status != PLASMA_SUCCESS) {
        plasma_error("PLASMA_sormqr", "plasma_tune() failed");
        return status;
    }

    /* Set MT, NT & NTRHS */
    NB = PLASMA_NB;
    MT = (M%NB==0) ? (M/NB) : (M/NB+1);
    KT = (K%NB==0) ? (K/NB) : (K/NB+1);
    NT = (N%NB==0) ? (N/NB) : (N/NB+1);

    /* Allocate memory for matrices in block layout */
    Abdl = (float *)plasma_shared_alloc(plasma, MT*KT*PLASMA_NBNBSIZE, PlasmaRealFloat);
    Tbdl = (float *)plasma_shared_alloc(plasma, MT*KT*PLASMA_IBNBSIZE, PlasmaRealFloat);
    Bbdl = (float *)plasma_shared_alloc(plasma, MT*NT*PLASMA_NBNBSIZE, PlasmaRealFloat);
    if (Abdl == NULL || Tbdl == NULL || Bbdl == NULL) {
        plasma_error("PLASMA_sormqr", "plasma_shared_alloc() failed");
        plasma_shared_free(plasma, Abdl);
        plasma_shared_free(plasma, Tbdl);
        plasma_shared_free(plasma, Bbdl);
        return PLASMA_ERR_OUT_OF_RESOURCES;
    }

    PLASMA_desc descA = plasma_desc_init(
        Abdl, PlasmaRealFloat,
        PLASMA_NB, PLASMA_NB, PLASMA_NBNBSIZE,
        M, K, 0, 0, M, K);

    PLASMA_desc descB = plasma_desc_init(
        Bbdl, PlasmaRealFloat,
        PLASMA_NB, PLASMA_NB, PLASMA_NBNBSIZE,
        M, N, 0, 0, M, N);

    PLASMA_desc descT = plasma_desc_init(
        Tbdl, PlasmaRealFloat,
        PLASMA_IB, PLASMA_NB, PLASMA_IBNBSIZE,
        M, K, 0, 0, M, K);

    plasma_parallel_call_3(plasma_lapack_to_tile,
        float*, A,
        int, LDA,
        PLASMA_desc, descA);

    plasma_parallel_call_3(plasma_lapack_to_tile,
        float*, B,
        int, LDB,
        PLASMA_desc, descB);

    /* Receive T from the user */
    plasma_memcpy(Tbdl, T, MT*KT*PLASMA_IBNBSIZE, PlasmaRealFloat);

    /* Call the native interface */
    status = PLASMA_sormqr_Tile(PlasmaLeft, PlasmaTrans, &descA, &descT, &descB);

    if (status == PLASMA_SUCCESS)
        plasma_parallel_call_3(plasma_tile_to_lapack,
            PLASMA_desc, descB,
            float*, B,
            int, LDB);

    plasma_shared_free(plasma, Abdl);
    plasma_shared_free(plasma, Tbdl);
    plasma_shared_free(plasma, Bbdl);
    return status;
}

/* /////////////////////////// P /// U /// R /// P /// O /// S /// E /////////////////////////// */
// PLASMA_sormqr_Tile - overwrites the general M-by-N matrix C with Q*C, where Q is an orthogonal
// matrix (unitary in the complex case) defined as the product of elementary reflectors returned
// by PLASMA_sgeqrf_Tile Q is of order M.
// All matrices are passed through descriptors. All dimensions are taken from the descriptors.

/* ///////////////////// A /// R /// G /// U /// M /// E /// N /// T /// S ///////////////////// */
// side     PLASMA_enum (IN)
//          Intended usage:
//          = PlasmaLeft:  apply Q or Q**T from the left;
//          = PlasmaRight: apply Q or Q**T from the right.
//          Currently only PlasmaLeft is supported.
//
// trans    PLASMA_enum (IN)
//          Intended usage:
//          = PlasmaNoTrans:   no transpose, apply Q;
//          = PlasmaTrans: conjugate transpose, apply Q**T.
//          Currently only PlasmaTrans is supported.
//
// A        float* (IN)
//          Details of the QR factorization of the original matrix A as returned by PLASMA_sgeqrf.
//
// T        float* (IN)
//          Auxiliary factorization data, computed by PLASMA_sgeqrf.
//
// B        float* (INOUT)
//          On entry, the M-by-N matrix B.
//          On exit, B is overwritten by Q*B or Q**T*B.

/* ///////////// R /// E /// T /// U /// R /// N /////// V /// A /// L /// U /// E ///////////// */
//          = 0: successful exit

/* //////////////////////////////////// C /// O /// D /// E //////////////////////////////////// */
int PLASMA_sormqr_Tile(PLASMA_enum side, PLASMA_enum trans, PLASMA_desc *A, PLASMA_desc *T,
                       PLASMA_desc *B)
{
    PLASMA_desc descA = *A;
    PLASMA_desc descT = *T;
    PLASMA_desc descB = *B;
    plasma_context_t *plasma;

    plasma = plasma_context_self();
    if (plasma == NULL) {
        plasma_fatal_error("PLASMA_sormqr_Tile", "PLASMA not initialized");
        return PLASMA_ERR_NOT_INITIALIZED;
    }
    /* Check descriptors for correctness */
    if (plasma_desc_check(&descA) != PLASMA_SUCCESS) {
        plasma_error("PLASMA_sormqr_Tile", "invalid first descriptor");
        return PLASMA_ERR_ILLEGAL_VALUE;
    }
    if (plasma_desc_check(&descT) != PLASMA_SUCCESS) {
        plasma_error("PLASMA_sormqr_Tile", "invalid second descriptor");
        return PLASMA_ERR_ILLEGAL_VALUE;
    }
    if (plasma_desc_check(&descB) != PLASMA_SUCCESS) {
        plasma_error("PLASMA_sormqr_Tile", "invalid third descriptor");
        return PLASMA_ERR_ILLEGAL_VALUE;
    }
    /* Check input arguments */
    if (descA.nb != descA.mb || descB.nb != descB.mb) {
        plasma_error("PLASMA_sormqr_Tile", "only square tiles supported");
        return PLASMA_ERR_ILLEGAL_VALUE;
    }
    if (side != PlasmaLeft) {
        plasma_error("PLASMA_sormqr_Tile", "only PlasmaLeft supported");
        return PLASMA_ERR_NOT_SUPPORTED;
    }
    if (trans != PlasmaTrans) {
        plasma_error("PLASMA_sormqr_Tile", "only PlasmaTrans supported");
        return PLASMA_ERR_NOT_SUPPORTED;
    }
    /* Quick return - currently NOT equivalent to LAPACK's:
     * CALL DLASET( 'Full', MAX( M, N ), NRHS, ZERO, ZERO, B, LDB ) */
/*
    if (min(M, min(N, K)) == 0)
        return PLASMA_SUCCESS;
*/
    plasma_parallel_call_3(plasma_psormqr,
        PLASMA_desc, descA,
        PLASMA_desc, descB,
        PLASMA_desc, descT);

    return PLASMA_SUCCESS;
}
