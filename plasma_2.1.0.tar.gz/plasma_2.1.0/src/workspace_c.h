/* ///////////////////////////// P /// L /// A /// S /// M /// A /////////////////////////////// */
/* ///                    PLASMA auxiliary routines (version 2.1.0)                          ///
 * ///                    Author: Jakub Kurzak                                               ///
 * ///                    Release Date: November, 15th 2009                                  ///
 * ///                    PLASMA is a software package provided by Univ. of Tennessee,       ///
 * ///                    Univ. of California Berkeley and Univ. of Colorado Denver          /// */
/* ///////////////////////////////////////////////////////////////////////////////////////////// */
#ifndef _WORKSPACE_C_H_
#define _WORKSPACE_C_H_

#ifdef __cplusplus
extern "C" {
#endif

int PLASMA_Alloc_Workspace_cgels(int M, int N, PLASMA_Complex32_t **T);
int PLASMA_Alloc_Workspace_cgeqrf(int M, int N, PLASMA_Complex32_t **T);
int PLASMA_Alloc_Workspace_cgelqf(int M, int N, PLASMA_Complex32_t **T);
int PLASMA_Alloc_Workspace_cgesv(int N, PLASMA_Complex32_t **L, int **IPIV);
int PLASMA_Alloc_Workspace_cgetrf(int M, int N, PLASMA_Complex32_t **L, int **IPIV);

#ifdef __cplusplus
}
#endif

#endif
