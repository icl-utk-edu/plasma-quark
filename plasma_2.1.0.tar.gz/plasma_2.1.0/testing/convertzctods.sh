../tools/convertzctods.sh testing_zcgesv.c testing_dsgesv.c
