/* ///////////////////////////// P /// L /// A /// S /// M /// A /////////////////////////////// */
/* ///                    PLASMA testing routines (version 2.1.0)                            ///
 * ///                    Author: Emmanuel Agullo                                            ///
 * ///                    Release Date: November, 15th 2009                                  ///
 * ///                    PLASMA is a software package provided by Univ. of Tennessee,       ///
 * ///                    Univ. of California Berkeley and Univ. of Colorado Denver          /// */
/* ///////////////////////////////////////////////////////////////////////////////////////////// */

/* /////////////////////////// P /// U /// R /// P /// O /// S /// E /////////////////////////// */
//  testing_zgemm : Test PLASMA_zgemm routine

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <cblas.h>
#include <plasma.h>
#include "../src/lapack.h"
#include "../src/core_blas.h"

#ifdef WIN32
#include <float.h>
#define isnan _isnan
#endif

#ifndef max
#define max(a, b) ((a) > (b) ? (a) : (b))
#endif
#ifndef min
#define min(a, b) ((a) < (b) ? (a) : (b))
#endif

int check_solution(PLASMA_enum transA, PLASMA_enum transB, int M, int N, int K,
                   PLASMA_Complex64_t alpha, PLASMA_Complex64_t *A, int LDA,
           PLASMA_Complex64_t *B, int LDB,
                   PLASMA_Complex64_t beta, PLASMA_Complex64_t *Cref, PLASMA_Complex64_t *Cplasma, int LDC);


int IONE=1;
int ISEED[4] = {0,0,0,1};   /* initial seed for zlarnv() */

int main (int argc, char **argv)
{
    /* Check for number of arguments*/
    if ( argc != 10){
        printf(" Proper Usage is : ./testing_zgemm ncores alpha beta M N K LDA LDB LDC with \n - ncores : number of cores \n - alpha : alpha coefficient \n - beta : beta coefficient \n - M : number of rows of matrices A and C \n - N : number of columns of matrices B and C \n - K : number of columns of matrix A / number of rows of matrix B \n - LDA : leading dimension of matrix A \n - LDB : leading dimension of matrix B \n - LDC : leading dimension of matrix C\n");
        exit(1);
    }

    int cores = atoi(argv[1]);
    PLASMA_Complex64_t alpha = (PLASMA_Complex64_t) atol(argv[2]);
    PLASMA_Complex64_t beta = (PLASMA_Complex64_t) atol(argv[3]);
    int M     = atoi(argv[4]);
    int N     = atoi(argv[5]);
    int K     = atoi(argv[6]);
    int LDA   = atoi(argv[7]);
    int LDB  = atoi(argv[8]);
    int LDC   = atoi(argv[9]);

    double eps;
    int info_solution;
    int i,j;
    int LDAxK = LDA*K;
    int LDBxN = LDB*N;
    int LDCxN = LDC*N;

    PLASMA_Complex64_t *A = (PLASMA_Complex64_t *)malloc(LDA*K*sizeof(PLASMA_Complex64_t));
    PLASMA_Complex64_t *B = (PLASMA_Complex64_t *)malloc(LDB*N*sizeof(PLASMA_Complex64_t));
    PLASMA_Complex64_t *Cinit = (PLASMA_Complex64_t *)malloc(LDC*N*sizeof(PLASMA_Complex64_t));
    PLASMA_Complex64_t *Cfinal = (PLASMA_Complex64_t *)malloc(LDC*N*sizeof(PLASMA_Complex64_t));

    /* Check if unable to allocate memory */
    if ((!A)||(!B)||(!Cinit)||(!Cfinal)){
        printf("Out of Memory \n ");
        exit(0);
    }

    /* Plasma Initialization */
    PLASMA_Init(cores);

    /*
    PLASMA_Disable(PLASMA_AUTOTUNING);
    PLASMA_Set(PLASMA_TILE_SIZE, 6);
    PLASMA_Set(PLASMA_INNER_BLOCK_SIZE, 3);
    */

    eps = dlamch("Epsilon");

    /*----------------------------------------------------------
    *  TESTING ZGEMM
    */

    /* Initialize A */
    zlarnv(&IONE, ISEED, &LDAxK, A);

    /* Initialize B */
    zlarnv(&IONE, ISEED, &LDBxN, B);

    /* Initialize C */
    zlarnv(&IONE, ISEED, &LDCxN, Cinit);
    for ( i = 0; i < M; i++)
        for (  j = 0; j < N; j++)
            Cfinal[LDC*j+i] = Cinit[LDC*j+i];

    /* PLASMA ZGEMM */
    PLASMA_zgemm(PlasmaNoTrans, PlasmaNoTrans, M, N, K, alpha, A, LDA, B, LDB, beta, Cfinal, LDC);

    printf("\n");
    printf("------ TESTS FOR PLASMA ZGEMM ROUTINE -------  \n");
    printf("            Size of the Matrix %d by %d\n", M, N);
    printf("\n");
    printf(" The matrix A is randomly generated for each test.\n");
    printf("============\n");
    printf(" The relative machine precision (eps) is to be %e \n",eps);
    printf(" Computational tests pass if scaled residuals are less than 10.\n");

    /* Check the solution */
    info_solution = check_solution(PlasmaNoTrans, PlasmaNoTrans, M, N, K, alpha, A, LDA, B, LDB, beta, Cinit, Cfinal, LDC);

    if (info_solution == 0) {
        printf("***************************************************\n");
        printf(" ---- TESTING ZGEMM ...................... PASSED !\n");
        printf("***************************************************\n");
    }
    else {
        printf("************************************************\n");
        printf(" - TESTING ZGEMM ... FAILED !\n");
        printf("************************************************\n");
    }

    free(A); free(B); free(Cinit); free(Cfinal);

    PLASMA_Finalize();

    exit(0);
}

/*--------------------------------------------------------------
 * Check the solution
 */

int check_solution(PLASMA_enum transA, PLASMA_enum transB, int M, int N, int K,
                   PLASMA_Complex64_t alpha, PLASMA_Complex64_t *A, int LDA,
           PLASMA_Complex64_t *B, int LDB,
                   PLASMA_Complex64_t beta, PLASMA_Complex64_t *Cref, PLASMA_Complex64_t *Cplasma, int LDC)
{
    int info_solution;
    double Anorm, Bnorm, Cinitnorm, Cplasmanorm, Crefnorm, Clapacknorm, Rnorm;
    double eps;
    char norm='I';
    PLASMA_Complex64_t alpha_const, beta_const;

    double *work = (double *)malloc(max(K,max(M, N))* sizeof(double));

    alpha_const = 1.0;
    beta_const  = -1.0;

    Anorm = zlange(&norm, &M, &K, A, &LDA, work);
    Bnorm = zlange(&norm, &K, &N, B, &LDB, work);
    Cinitnorm = zlange(&norm, &M, &N, Cref, &LDC, work);
    Cplasmanorm = zlange(&norm, &M, &N, Cplasma, &LDC, work);

    CORE_zgemm(transA, transB, M, N, K, (alpha), A, LDA, B, LDB, (beta), Cref, LDC);

    Clapacknorm = zlange(&norm, &M, &N, Cref, &LDC, work);

    cblas_zaxpy(LDC * N, CBLAS_SADDR(beta_const), Cplasma, 1, Cref, 1);

    Rnorm = zlange(&norm, &M, &N, Cref, &LDC, work);

    eps = dlamch("Epsilon");

    printf("Rnorm %e, Anorm %e, Bnorm %e, Cinitnorm %e, Cplasmanorm %e, Clapacknorm %e\n",Rnorm,Anorm,Bnorm,Cinitnorm,Cplasmanorm,Clapacknorm);

    printf("============\n");
    printf("Checking the norm of the difference against reference ZGEMM \n");
    printf("-- ||Cplasma - Clapack||_oo/((||A||_oo+||B||_oo+||C||_oo).N.eps) = %e \n", Rnorm / ((Anorm + Bnorm + Cinitnorm) * N * eps));

    if (isnan(Rnorm / ((Anorm + Bnorm + Cinitnorm) * N * eps)) || (Rnorm / ((Anorm + Bnorm + Cinitnorm) * N * eps) > 10.0) ) {
         printf("-- The solution is suspicious ! \n");
         info_solution = 1;
    }
    else {
         printf("-- The solution is CORRECT ! \n");
         info_solution= 0 ;
    }

    free(work);

    return info_solution;
}
