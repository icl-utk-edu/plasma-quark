#!/bin/bash
IN=$1
OUT=$2

sed -e "s/ZC/DS/g" -e "s/zc/ds/g" -e "s/PLASMA_Complex64_t/double/g" -e "s/PLASMA_Complex32_t/float/g" -e "s/PlasmaComplexDouble/PlasmaRealDouble/g" -e "s/PlasmaComplexFloat/PlasmaRealFloat/g" -e "s/zlange/dlange/g" -e "s/zlag2c/dlag2s/g" -e "s/clag2z/slag2d/g" -e "s/zlacpy/dlacpy/g" -e "s/zgemm/dgemm/g" -e "s/zaxpy/daxpy/g" -e "s/pzgetrf/pdgetrf/g" -e "s/pcgetrf/psgetrf/g" -e "s/ztrsm/dtrsm/g" -e "s/ctrsm/strsm/g" -e "s/CBLAS_SADDR//g" -e "s/CBLAS_SADDR//g"  -e "s/zlarnv/dlarnv/g" -e "s/zgesv/dgesv/g" $IN > $OUT
